<!-- _coverpage.md -->

![logo](img/icon.svg)

# AutoCharts <small>v2.3.0</small>

> A magical quarterly marketing updater.

- Simple and lightweight
- Runs locally
- Fully documented

[GitHub](https://github.com/oNevion/AutoCharts)
[Get Started](#main)