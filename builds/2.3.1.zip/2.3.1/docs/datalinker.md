# DataLinker

This page will go over the InDesign plugin [DataLinker](http://www.teacupsoftware.com/product/datalinker/) and how it is utilized for AutoCharts

## What is DataLinker?



## How is it used?



## Data Sources

 

## Troubleshooting

